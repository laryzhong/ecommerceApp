<?php
$file_name="http://127.0.0.1/data/add_shop_data.json ";
$file=file_get_contents($file_name);
echo $file;