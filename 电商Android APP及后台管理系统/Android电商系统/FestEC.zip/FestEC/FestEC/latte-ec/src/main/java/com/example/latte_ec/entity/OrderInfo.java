package com.example.latte_ec.entity;

/**
 * Created by luxiaoguo on 2018/7/6.
 */

public class OrderInfo {
}
