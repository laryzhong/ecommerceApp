package com.example.latte_ec.main.cart;

public enum ShopCartItemFields {
    TITLE,
    DESC,
    COUNT,
    PRICE,
    IS_SELECTED,//标记是否被点击
    POSITION
}