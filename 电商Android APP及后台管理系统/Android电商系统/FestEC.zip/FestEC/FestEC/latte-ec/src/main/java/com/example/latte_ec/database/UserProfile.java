package com.example.latte_ec.database;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;

/**
 * Created by luxiaoguo on 2018/6/6.
 */


@Entity(nameInDb = "user_profile")
public class UserProfile {
    @Id
    private String userId = null;
    private String userName = null;
    private String userEmail= null;
    private String userPhone = null;
    private String passWord = null;
    private String userSex=null;
    private String headPortrait=null;
    private String userBirth=null;

    @Generated(hash = 841209825)
    public UserProfile(String userId, String userName, String userEmail,
            String userPhone, String passWord, String userSex, String headPortrait,
            String userBirth) {
        this.userId = userId;
        this.userName = userName;
        this.userEmail = userEmail;
        this.userPhone = userPhone;
        this.passWord = passWord;
        this.userSex = userSex;
        this.headPortrait = headPortrait;
        this.userBirth = userBirth;
    }

    @Generated(hash = 968487393)
    public UserProfile() {
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public String getUserSex() {
        return userSex;
    }

    public void setUserSex(String userSex) {
        this.userSex = userSex;
    }

    public String getHeadPortrait() {
        return headPortrait;
    }

    public void setHeadPortrait(String headPortrait) {
        this.headPortrait = headPortrait;
    }

    public String getUserBirth() {
        return userBirth;
    }

    public void setUserBirth(String userBirth) {
        this.userBirth = userBirth;
    }
}
