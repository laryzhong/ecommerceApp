package com.example.latte_ec.main.index.search;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.latte_ui.recycler.DataConverter;
import com.example.latte_ui.recycler.ItemType;
import com.example.latte_ui.recycler.MultipleFields;
import com.example.latte_ui.recycler.MultipleItemEntity;
import com.example.latte.util.storage.LattePreference;

import java.util.ArrayList;



public class SearchDataConverter extends DataConverter {

//    public static final String TAG_SEARCH_HISTORY = "search_history";

    @Override
    public ArrayList<MultipleItemEntity> convert() {
//        final String jsonStr =
//                LattePreference.getCustomAppProfile(TAG_SEARCH_HISTORY);
//        if (!jsonStr.equals("")) {
//            final JSONArray array = JSONArray.parseArray(jsonStr);
//            final int size = array.size();
//            for (int i = 0; i < size; i++) {
//                final String historyItemText = array.getString(i);
//                final MultipleItemEntity entity = MultipleItemEntity.builder()
//                        .setItemType(SearchItemType.ITEM_SEARCH)
//                        .setField(MultipleFields.TEXT, historyItemText)
//                        .build();
//                ENTITIES.add(entity);
//            }
//        }
//        return ENTITIES;


        final JSONArray dataArray= JSON.parseObject(getJsonData()).getJSONArray("data");

        final int size=dataArray.size();
        for (int i=0;i<size;i++){
            final JSONObject data=dataArray.getJSONObject(i);

            final String imageUrl=data.getString("imageUrl");
            final String text=data.getString("text");
            final int spanSize=data.getInteger("spanSize");
            final int id=data.getInteger("goodsId");

            int type=0;
            if (imageUrl==null&&text!=null){
                type= ItemType.TEXT;
            }else if (imageUrl!=null&&text==null){
                type=ItemType.IMAGE;
            }else if(imageUrl!=null){
                type=ItemType.TEXT_IMAGE;
            }

            final MultipleItemEntity entity=MultipleItemEntity.builder()
                    .setField(MultipleFields.ITEM_TYPE,type)
                    .setField(MultipleFields.SPAN_SIZE,spanSize)
                    .setField(MultipleFields.ID,id)
                    .setField(MultipleFields.TEXT,text)
                    .setField(MultipleFields.IMAGE_URL,imageUrl)
                    .build();
            ENTITIES.add(entity);
        }
        return ENTITIES;

    }
}
