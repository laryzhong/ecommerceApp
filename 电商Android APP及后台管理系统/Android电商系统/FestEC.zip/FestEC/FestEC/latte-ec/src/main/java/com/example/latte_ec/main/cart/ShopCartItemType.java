package com.example.latte_ec.main.cart;



 class ShopCartItemType {

    static final int SHOP_CART_ITEM = 6;
}
