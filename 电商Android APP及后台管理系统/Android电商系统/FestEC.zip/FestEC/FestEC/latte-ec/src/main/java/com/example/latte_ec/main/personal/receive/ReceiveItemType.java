package com.example.latte_ec.main.personal.receive;

/**
 * Created by luxiaoguo on 2018/6/29.
 */

class ReceiveItemType {

    static final int SHOP_CART_ITEM = 6;
}