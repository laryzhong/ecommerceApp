package com.example.latte_ec.sign;

/**
 * Created by luxiaoguo on 2018/6/6.
 */

public interface ISignListener {
    void onSignInSuccess();
    void onSignUpSuccess();
}
