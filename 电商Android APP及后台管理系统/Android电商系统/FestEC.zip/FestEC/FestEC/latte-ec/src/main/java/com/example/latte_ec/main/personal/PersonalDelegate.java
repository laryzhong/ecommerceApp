package com.example.latte_ec.main.personal;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.latte.util.file.FileUtil;
import com.example.latte.util.log.LatteLogger;
import com.example.latte_ec.R;
import com.example.latte_ec.R2;
import com.example.latte.delegates.bottom.BottomItemDelegate;
import com.example.latte_ec.database.DatabaseManager;
import com.example.latte_ec.database.UserProfile;
import com.example.latte_ec.main.cart.ShopCartDelegate;
import com.example.latte_ec.main.personal.evaluate.EvaluateDelegate;
import com.example.latte_ec.main.personal.order.OrderListDelegate;
import com.example.latte_ec.main.personal.address.AddressDelegate;
import com.example.latte_ec.main.personal.list.ListAdapter;
import com.example.latte_ec.main.personal.list.ListBean;
import com.example.latte_ec.main.personal.list.ListItemType;
import com.example.latte_ec.main.personal.payment.PaymentDelegate;
import com.example.latte_ec.main.personal.profile.UserProfileDelegate;
import com.example.latte_ec.main.personal.receive.ReceiveDelegate;
import com.example.latte_ec.main.personal.settings.SettingsDelegate;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import de.hdodenhof.circleimageview.CircleImageView;


public class PersonalDelegate extends BottomItemDelegate {

    @BindView(R2.id.rv_personal_setting)
    RecyclerView mRvSettings = null;

    public static final String ORDER_TYPE = "ORDER_TYPE";
    private Bundle mArgs = null;

    @Override
    public Object setLayout() {
        return R.layout.delegate_personal;
    }

    @BindView(R2.id.img_user_avatar)
    CircleImageView mArrowAvatar=null;


    @BindView(R2.id.txt_user_name)
    TextView txtName=null;

    @OnClick(R2.id.tv_all_order)
    void onClickAllOrder() {
        mArgs.putString(ORDER_TYPE, "all");
        startOrderListByType();
    }


    @OnClick(R2.id.img_user_avatar)
    void onClickAvatar() {
        getParentDelegate().getSupportDelegate().start(new UserProfileDelegate());
    }


    @OnClick(R2.id.ll_pay)
    void onClickLlPay(){
        getParentDelegate().getSupportDelegate().start(new PaymentDelegate());
    }

    @OnClick(R2.id.ll_receive)
    void onClickLlReceive(){
        getParentDelegate().getSupportDelegate().start(new ReceiveDelegate());
    }

    @OnClick(R2.id.ll_evaluate)
    void onClickLlEvaluate(){
        mArgs.putString(ORDER_TYPE, "all");
        startLlEvaluate();
    }

    @OnClick(R2.id.ll_after_market)
    void onClickLlAfterMarket(){

    }

    private void startLlEvaluate(){
        final EvaluateDelegate delegate = new EvaluateDelegate();
        delegate.setArguments(mArgs);
        getParentDelegate().getSupportDelegate().start(delegate);
    }

    private void startOrderListByType() {
        final OrderListDelegate delegate = new OrderListDelegate();
        delegate.setArguments(mArgs);
        getParentDelegate().getSupportDelegate().start(delegate);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mArgs = new Bundle();
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

//本地资源
    public Bitmap getBitmapStream(int id)
    {
        BitmapFactory.Options bmFactOpt = new BitmapFactory.Options();
        bmFactOpt.inPreferredConfig = Bitmap.Config.RGB_565;//表示16位位图 565代表对应三原色占的位数
        bmFactOpt.inInputShareable = true;
        bmFactOpt.inPurgeable = true;//设置图片可以被回收
        InputStream is = getResources().openRawResource(id);
        Bitmap bitmap = BitmapFactory.decodeStream(is, null, bmFactOpt);//比decodeResource()节省内存
        try
        {
            is.close();
        } catch (IOException e)
        {
            e.printStackTrace();
        }
        return bitmap;
    }

//url资源
    public static Bitmap getBitMap(String url){
        URL myFileUrl = null;
        Bitmap bitmap = null;
        BitmapFactory.Options bmFactOpt = new BitmapFactory.Options();
        bmFactOpt.inPreferredConfig = Bitmap.Config.RGB_565;//表示16位位图 565代表对应三原色占的位数
        bmFactOpt.inInputShareable = true;
        bmFactOpt.inPurgeable = true;//设置图片可以被回收
        try {
            myFileUrl = new URL(url);
        } catch (MalformedURLException e) {
            LatteLogger.e("IOException1:",e.getMessage());
            e.printStackTrace();
        }
        try {
            HttpURLConnection conn = (HttpURLConnection) myFileUrl.openConnection();
            conn.setDoInput(true);
            conn.connect();
            InputStream is = conn.getInputStream();
            bitmap = BitmapFactory.decodeStream(is,null, bmFactOpt);
            is.close();
        } catch (IOException e) {
            LatteLogger.e("IOException2:",e.getMessage());
            e.printStackTrace();
        }
        return bitmap;
    }

    @Override
    public void onBindView(@Nullable Bundle savedInstanceState, @NonNull View rootView) {
        List<UserProfile> areas = DatabaseManager.getInstance().getmDao().loadAll();
        String userHeadPortrait=areas.get(0).getHeadPortrait();
        Bitmap bitmap = null;
        bitmap=getBitMap(userHeadPortrait);
        mArrowAvatar.setImageBitmap(bitmap);

        String userName=areas.get(0).getUserName();
        txtName.setText(userName);

        final ListBean address = new ListBean.Builder()
                .setItemType(ListItemType.ITEM_NORMAL)
                .setId(1)
                .setDelegate(new AddressDelegate())
                .setText("收货地址")
                .build();

        final ListBean system = new ListBean.Builder()
                .setItemType(ListItemType.ITEM_NORMAL)
                .setId(2)
                .setDelegate(new SettingsDelegate())
                .setText("系统设置")
                .build();


        final ListBean exit = new ListBean.Builder()
                .setItemType(ListItemType.ITEM_NORMAL)
                .setId(3)
                .setText("退出登录")
                .build();

        final List<ListBean> data = new ArrayList<>();
        data.add(address);
        data.add(system);

        //设置RecyclerView
        final LinearLayoutManager manager = new LinearLayoutManager(getContext());
        mRvSettings.setLayoutManager(manager);
        final ListAdapter adapter = new ListAdapter(data);
        mRvSettings.setAdapter(adapter);
        mRvSettings.addOnItemTouchListener(new PersonalClickListener(this));
    }
}
