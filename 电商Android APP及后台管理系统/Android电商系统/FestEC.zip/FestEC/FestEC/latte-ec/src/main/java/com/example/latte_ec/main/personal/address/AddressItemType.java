package com.example.latte_ec.main.personal.address;



public class AddressItemType {
    static final int ITEM_ADDRESS = 40;
}
