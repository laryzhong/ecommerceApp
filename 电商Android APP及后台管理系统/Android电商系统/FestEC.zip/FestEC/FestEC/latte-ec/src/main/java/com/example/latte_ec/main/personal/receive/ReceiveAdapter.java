package com.example.latte_ec.main.personal.receive;

import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutCompat;
import android.view.View;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.latte.net.RestClient;
import com.example.latte.net.callback.ISuccess;
import com.example.latte.util.log.LatteLogger;
import com.example.latte_ec.R;
import com.example.latte_ec.database.DatabaseManager;
import com.example.latte_ec.database.UserProfile;
import com.example.latte_ec.main.cart.ICartItemListener;
import com.example.latte_ec.main.cart.ShopCartItemFields;
import com.example.latte_ui.recycler.MultipleFields;
import com.example.latte_ui.recycler.MultipleItemEntity;
import com.example.latte_ui.recycler.MultipleRecyclerAdapter;
import com.example.latte_ui.recycler.MultipleViewHolder;
import com.joanzapata.iconify.widget.IconTextView;

import java.util.List;

/**
 * Created by luxiaoguo on 2018/6/29.
 */

public class ReceiveAdapter extends MultipleRecyclerAdapter {

    private ICartItemListener mCartItemListener = null;

    private static final RequestOptions OPTIONS = new RequestOptions()
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .centerCrop()
            .dontAnimate();

    public ReceiveAdapter(List<MultipleItemEntity> data) {
        super(data);
        addItemType(ReceiveItemType.SHOP_CART_ITEM, R.layout.item_ll_receive);
    }


    public void setCartItemListener(ICartItemListener listener) {
        this.mCartItemListener = listener;
    }


    @Override
    protected void convert(MultipleViewHolder holder, final MultipleItemEntity entity) {
        super.convert(holder, entity);
        switch (holder.getItemViewType()) {
            case ReceiveItemType.SHOP_CART_ITEM:
                //先取出所有值

                List<UserProfile> areas = DatabaseManager.getInstance().getmDao().loadAll();
                final String userId=areas.get(0).getUserId();
                final int id = entity.getField(MultipleFields.ID);
                final String thumb = entity.getField(MultipleFields.IMAGE_URL);
                final String title = entity.getField(ShopCartItemFields.TITLE);
                final String desc = entity.getField(ShopCartItemFields.DESC);
                final int count = entity.getField(ShopCartItemFields.COUNT);
                final double price = entity.getField(ShopCartItemFields.PRICE);
                //取出所以控件
                final AppCompatImageView imgThumb = holder.getView(R.id.image_item_ll_receive);
                final AppCompatTextView tvTitle = holder.getView(R.id.tv_item_ll_pay_receive);
                final AppCompatTextView tvDesc = holder.getView(R.id.tv_item_ll_receive_desc);
                final AppCompatTextView tvPrice = holder.getView(R.id.tv_item_ll_receive_price);
                final LinearLayoutCompat btn_yes=holder.getView(R.id.btn_ll_receive);
                final AppCompatTextView txtReceive=holder.getView(R.id.txt_receive);

                //赋值
                tvTitle.setText(title);
                tvDesc.setText(desc);
                tvPrice.setText(String.valueOf(price*count));
                Glide.with(mContext)
                        .load(thumb)
                        .apply(OPTIONS)
                        .into(imgThumb);

                btn_yes.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        RestClient.builder()
                                .url("add_receive.php")
                                .loader(mContext)
                                .params("goodsId",id)
                                .params("userId",userId)
                                .success(new ISuccess() {
                                    @Override
                                    public void onSuccess(String response) {
                                        LatteLogger.json("receive", response);
                                        final boolean isAdded = JSON.parseObject(response).getBoolean("data");
                                        if (isAdded){
                                            txtReceive.setText("已收货");
                                        }
                                    }
                                })
                                .build()
                                .post();
                    }
                });
                break;
            default:
                break;
        }
    }
}
