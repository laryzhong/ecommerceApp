package com.example.latte_ec.main.cart;



public interface ICartItemListener {
    void onItemClick(double itemTotalPrice);
}
