package com.example.latte_ec.main.index.search;



public class SearchItemType {

    static final int ITEM_SEARCH = 50;
}
