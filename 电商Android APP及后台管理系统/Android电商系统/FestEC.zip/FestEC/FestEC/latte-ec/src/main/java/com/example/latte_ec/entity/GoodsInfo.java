package com.example.latte_ec.entity;

/**
 * Created by luxiaoguo on 2018/6/6.
 */

public class GoodsInfo {
    private String imageUrl;
    private String text;
    private int spanSize;
    private int id;

    public String getImageUrl() {
        return imageUrl;
    }

    public String getText() {
        return text;
    }

    public int getSpanSize() {
        return spanSize;
    }

    public int getId() {
        return id;
    }
}
