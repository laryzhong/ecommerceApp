package com.example.latte_ec.main.personal.list;



public class ListItemType {

    public static final int ITEM_NORMAL = 20;
    public static final int ITEM_AVATAR = 21;
    public static final int ITEM_SWITCH = 22;
}
