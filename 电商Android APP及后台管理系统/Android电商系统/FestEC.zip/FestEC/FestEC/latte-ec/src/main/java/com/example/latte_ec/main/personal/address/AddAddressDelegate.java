package com.example.latte_ec.main.personal.address;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.view.View;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.example.latte.delegates.LatteDelegate;
import com.example.latte.net.RestClient;
import com.example.latte.net.callback.ISuccess;
import com.example.latte.util.log.LatteLogger;
import com.example.latte_ec.R;
import com.example.latte_ec.R2;
import com.example.latte_ec.database.DatabaseManager;
import com.example.latte_ec.database.UserProfile;
import com.example.latte_ec.main.EcBottomDelegate;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by luxiaoguo on 2018/6/28.
 */

public class AddAddressDelegate extends LatteDelegate {
    @Override
    public Object setLayout() {
        return R.layout.delegate_add_address;
    }

    @BindView(R2.id.edit_add_name)
    TextInputEditText mAddName=null;

    @BindView(R2.id.edit_add_address)
    TextInputEditText mAddAddress=null;

    @BindView(R2.id.edit_add_phone)
    TextInputEditText mAddPhone=null;

    @OnClick(R2.id.btn_add_up)
    void onClickAddAddress(){
        String name= String.valueOf(mAddName.getText());
        String address=String.valueOf(mAddAddress.getText());
        String phone=String.valueOf(mAddPhone.getText());

        final List<UserProfile> areas = DatabaseManager.getInstance().getmDao().loadAll();
        final String userId=areas.get(0).getUserId();

        RestClient.builder()
                .url("add_address.php")
                .params("userId",userId)
                .params("name",name)
                .params("address",address)
                .params("phone",phone)
                .success(new ISuccess() {
                    @Override
                    public void onSuccess(String response) {
                        //获取更新后的用户信息，然后更新本地数据库
                        //没有本地数据的APP，每次打开APP都请求API，获取信息
                        LatteLogger.json("add_address", response);
                        final boolean isAdded = JSON.parseObject(response).getBoolean("data");
                        if (isAdded){
                            Toast.makeText(getContext(),"添加成功",Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .build()
                .post();

        EcBottomDelegate delegate=new EcBottomDelegate();
        delegate.setKey(4);
        getSupportDelegate().start(delegate);
    }

    @Override
    public void onBindView(@Nullable Bundle savedInstanceState, @NonNull View rootView) {

    }
}
