package com.example.latte_ec.main.personal.receive;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.example.latte.delegates.LatteDelegate;
import com.example.latte.net.RestClient;
import com.example.latte.net.callback.ISuccess;
import com.example.latte_ec.R;
import com.example.latte_ec.R2;
import com.example.latte_ec.database.DatabaseManager;
import com.example.latte_ec.database.UserProfile;
import com.example.latte_ec.main.cart.ICartItemListener;
import com.example.latte_ec.main.cart.ShopCartAdapter;
import com.example.latte_ec.main.cart.ShopCartDataConverter;
import com.example.latte_ec.pay.IAlPayResultListener;
import com.example.latte_ui.recycler.MultipleItemEntity;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by luxiaoguo on 2018/6/29.
 */

public class ReceiveDelegate extends LatteDelegate implements
        ISuccess
        ,ICartItemListener
        ,IAlPayResultListener {

    private ReceiveAdapter mAdapter = null;

    @BindView(R2.id.rv_ll_receive)
    RecyclerView mRecyclerView = null;

    @Override
    public Object setLayout() {
        return R.layout.delegate_ll_receive;
    }

    @Override
    public void onBindView(@Nullable Bundle savedInstanceState, @NonNull View rootView) {

    }


    @Override
    public void onLazyInitView(@Nullable Bundle savedInstanceState) {
        super.onLazyInitView(savedInstanceState);


        List<UserProfile> areas = DatabaseManager.getInstance().getmDao().loadAll();
        String userId = areas.get(0).getUserId();

        RestClient.builder()
                .url("receive.php")
                .params("userId", userId)
                .loader(getContext())
                .success(this)
                .build()
                .get();
    }

    @Override
    public void onSuccess(String response) {
        final ArrayList<MultipleItemEntity> data =
                new ShopCartDataConverter()
                        .setJsonData(response)
                        .convert();
        mAdapter = new ReceiveAdapter(data);
        mAdapter.setCartItemListener(this);
        final LinearLayoutManager manager = new LinearLayoutManager(getContext());
        mRecyclerView.setLayoutManager(manager);
        mRecyclerView.setAdapter(mAdapter);
    }

    @Override
    public void onPaySuccess() {

    }

    @Override
    public void onPaying() {

    }

    @Override
    public void onPayFail() {

    }

    @Override
    public void onPayCancel() {

    }

    @Override
    public void onPayConnectError() {

    }

    @Override
    public void onItemClick(double itemTotalPrice) {

    }
}
