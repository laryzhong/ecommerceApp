package com.example.latte_ec.sign;

import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.latte.app.AccountManager;
import com.example.latte_ec.database.DatabaseManager;
import com.example.latte_ec.database.UserProfile;

/**
 * Created by luxiaoguo on 2018/6/6.
 */

public class SignHandler {

    public  static void onSignIn(String response,ISignListener signListener){
        final JSONObject profileJson= JSON.parseObject(response).getJSONObject("data");
        final String userId = profileJson.getString("userId");
        final String userName = profileJson.getString("username");
        final String userEmail = profileJson.getString("UserEmail");
        final String userPhone = profileJson.getString("UserPhone");
        final String passWord = profileJson.getString("password");
        final String userSex=profileJson.getString("UserSex");
        final String headPortrait=profileJson.getString("HeadPortrait");
        final String userBirth=profileJson.getString("UserBirth");

        final UserProfile profile=new UserProfile(userId,userName,userEmail,userPhone,passWord,userSex,headPortrait,userBirth);
        DatabaseManager.getInstance().getmDao().insert(profile);

        //已经登录成功
        AccountManager.setSignState(true);
        signListener.onSignInSuccess();
    }


    public  static void onSignUp(String response,ISignListener signListener){
        final JSONObject profileJson= JSON.parseObject(response).getJSONObject("data");
        final String userId = profileJson.getString("userId");
        final String userName = profileJson.getString("username");
        final String userEmail = profileJson.getString("UserEmail");
        final String userPhone = profileJson.getString("UserPhone");
        final String passWord = profileJson.getString("password");

//        final UserProfile profile=new UserProfile(userId,userName,userEmail,userPhone,passWord);
//        DatabaseManager.getInstance().getmDao().insert(profile);

        //已经注册成功
        AccountManager.setSignState(true);
        signListener.onSignUpSuccess();
    }
}
