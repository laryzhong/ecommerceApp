package com.example.latte_ec.main.personal.order;



public class OrderListItemType {

    public static final int ITEM_ORDER_LIST = 30;
}
