package com.example.latte_ec.main.personal.settings;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.example.latte.net.RestClient;
import com.example.latte.net.callback.ISuccess;
import com.example.latte.util.log.LatteLogger;
import com.example.latte_ec.R;
import com.example.latte.delegates.LatteDelegate;
import com.example.latte_ec.R2;
import com.example.latte_ec.database.DatabaseManager;
import com.example.latte_ec.database.UserProfile;
import com.example.latte_ec.main.personal.profile.UserProfileDelegate;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;


public class NameDelegate extends LatteDelegate {
    @Override
    public Object setLayout() {
        return R.layout.delegate_name;
    }

    @BindView(R2.id.et_user_name)
    AppCompatEditText mUserName=null;

    @OnClick(R2.id.icon_edit_name_back)
    void onClickEditName(){
        getSupportDelegate().start(new UserProfileDelegate());
    }

    @OnClick(R2.id.btn_name_submit)
    void onClickSubName() {
        final List<UserProfile> areas = DatabaseManager.getInstance().getmDao().loadAll();
        final String userId=areas.get(0).getUserId();
        final String userName= String.valueOf(mUserName.getText());
        RestClient.builder()
                .url("update_user_data.php")
                .params("userName", userName)
                .params("userId",userId)
                .params("key",2)
                .success(new ISuccess() {
                    @Override
                    public void onSuccess(String response) {
                        //获取更新后的用户信息，然后更新本地数据库
                        //没有本地数据的APP，每次打开APP都请求API，获取信息
                        LatteLogger.json("update_user_data", response);
                        final boolean isAdded = JSON.parseObject(response).getBoolean("data");

                        if (isAdded){
                            UserProfile userProfile=areas.get(0);
                            userProfile.setUserName(userName);
                            DatabaseManager.getInstance().getmDao().update(userProfile);
                        }
                    }
                })
                .build()
                .post();

        Toast.makeText(getContext(),"修改成功！",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBindView(@Nullable Bundle savedInstanceState, @NonNull View rootView) {

    }
}
