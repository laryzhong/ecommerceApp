package com.example.latte_ec.main.personal.address;



public enum AddressItemFields {
    PHONE,
    ADDRESS
}
