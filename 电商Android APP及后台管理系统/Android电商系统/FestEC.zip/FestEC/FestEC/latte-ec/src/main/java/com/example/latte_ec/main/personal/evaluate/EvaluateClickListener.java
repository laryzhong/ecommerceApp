package com.example.latte_ec.main.personal.evaluate;

import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.SimpleClickListener;
import com.example.latte_ec.main.personal.order.OrderCommentDelegate;

/**
 * Created by luxiaoguo on 2018/6/27.
 */

public class EvaluateClickListener extends SimpleClickListener {
    private final EvaluateDelegate DELEGATE;

    public EvaluateClickListener(EvaluateDelegate delegate) {
        DELEGATE = delegate;
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
        DELEGATE.getSupportDelegate().start(new OrderCommentDelegate());
    }

    @Override
    public void onItemLongClick(BaseQuickAdapter adapter, View view, int position) {

    }

    @Override
    public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {

    }

    @Override
    public void onItemChildLongClick(BaseQuickAdapter adapter, View view, int position) {

    }
}
