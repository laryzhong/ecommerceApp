package com.example.latte_ec.main.personal.profile;



public class UploadConfig {

    public static final String API_HOST = "http://192.168.191.1/";//服务器域名
    public static final String UPLOAD_IMG = API_HOST + "image/userHeadImg/";//上传地址
}
