package com.example.latte_ec.main.personal.order;



public enum OrderItemFields {
    PRICE,
    TIME
}
