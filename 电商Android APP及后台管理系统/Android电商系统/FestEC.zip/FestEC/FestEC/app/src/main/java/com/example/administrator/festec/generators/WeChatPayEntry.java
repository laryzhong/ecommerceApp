package com.example.administrator.festec.generators;

import com.example.annotations.PayEntryGenerator;
import com.example.latte.wechat.templates.WXPayEntryTemplate;

/**
 * Created by luxiaoguo on 2018/6/7.
 */

@PayEntryGenerator(
        packageName = "com.example.administrator.festec",
        payEntryTemplete = WXPayEntryTemplate.class
)
public interface WeChatPayEntry {
}
