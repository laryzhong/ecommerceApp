package com.example.administrator.festec.generators;

import com.example.annotations.AppRegisterGenerator;
import com.example.latte.wechat.templates.AppRegisterTemplate;

/**
 * Created by luxiaoguo on 2018/6/7.
 */

@AppRegisterGenerator(
        packageName = "com.example.administrator.festec",
        registerTemplate = AppRegisterTemplate.class
)
public interface AppRegister {
}
