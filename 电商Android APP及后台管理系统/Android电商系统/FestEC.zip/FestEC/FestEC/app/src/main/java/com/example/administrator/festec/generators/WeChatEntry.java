package com.example.administrator.festec.generators;

import com.example.annotations.EntryGenerator;
import com.example.latte.wechat.templates.WXEntryTemplate;

/**
 * Created by luxiaoguo on 2018/6/7.
 */

@EntryGenerator(
        packageName = "com.example.administrator.festec",
        entryTemplete = WXEntryTemplate.class
)
public interface WeChatEntry {
}
