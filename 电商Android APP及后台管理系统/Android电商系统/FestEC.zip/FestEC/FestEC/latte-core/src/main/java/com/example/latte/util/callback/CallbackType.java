package com.example.latte.util.callback;



public enum CallbackType {
    ON_CROP,
    TAG_OPEN_PUSH,
    TAG_STOP_PUSH,
    ON_SCAN
}
