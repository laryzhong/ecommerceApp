package com.example.latte.app;

/**
 * Created by luxiaoguo on 2018/5/19.
 */

public enum ConfigKeys {
    API_HOST,//存储网络请求的域名
    APPLICATION_CONTEXT,//全局的上下文
    CONFIG_READY,//控制初始化配置完成了没有
    ICON,//存储自己的一些初始化项目
    LOADER_DELAYED,
    INTERCEPTOR,
    WE_CHAT_APP_ID,
    WE_CHAT_APP_SECRET,
    ACTIVITY,
    HANDLER,
    JAVASCRIPT_INTERFACE

}
