package com.example.latte.delegates.web.route;


/**
 * Created by luxiaoguo on 2018/6/14.
 */

public enum RouteKeys {
    /**
     * WEB页面跳转必须传递的参数
     */
    URL
}
