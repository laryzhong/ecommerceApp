package com.example.latte.wechat.callbacks;

/**
 * Created by luxiaoguo on 2018/6/7.
 */

public interface IWeChatSignInCallback {
    void onSignInSuccess(String userInfo);
}
