package com.example.latte.util.timer;

/**
 * Created by luxiaoguo on 2018/5/31.
 */

public interface ITimerListener {
    void onTimer();

}
