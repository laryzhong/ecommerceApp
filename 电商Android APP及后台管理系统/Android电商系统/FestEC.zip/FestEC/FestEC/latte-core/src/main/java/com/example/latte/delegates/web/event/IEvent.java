package com.example.latte.delegates.web.event;


public interface IEvent {

    String execute(String params);
}
