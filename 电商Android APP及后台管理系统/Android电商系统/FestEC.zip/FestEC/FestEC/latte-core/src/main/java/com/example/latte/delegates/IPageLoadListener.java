package com.example.latte.delegates;



public interface IPageLoadListener {

    void onLoadStart();

    void onLoadEnd();
}
