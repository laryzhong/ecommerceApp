package com.example.latte.net.callback;

/**
 * Created by luxiaoguo on 2018/5/25.
 */

public interface IFailure {
    void onFailure();
}
