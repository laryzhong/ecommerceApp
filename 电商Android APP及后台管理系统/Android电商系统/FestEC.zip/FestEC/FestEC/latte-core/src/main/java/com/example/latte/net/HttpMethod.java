package com.example.latte.net;

/**
 * Created by luxiaoguo on 2018/5/25.
 */

public enum HttpMethod {
    GET,
    POST,
    POST_RAW,
    PUT,
    PUT_RAW,
    DELETE,
    UPLOAD
}
