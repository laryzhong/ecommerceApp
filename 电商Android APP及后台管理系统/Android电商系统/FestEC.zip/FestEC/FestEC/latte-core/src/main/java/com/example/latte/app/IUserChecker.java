package com.example.latte.app;

/**
 * Created by luxiaoguo on 2018/6/6.
 */

public interface IUserChecker {

    void onSignIn();
    void onNotSignIn();
}
