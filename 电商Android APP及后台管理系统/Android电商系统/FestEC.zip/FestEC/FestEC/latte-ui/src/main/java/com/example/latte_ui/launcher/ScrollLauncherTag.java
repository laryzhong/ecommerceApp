package com.example.latte_ui.launcher;

/**
 * Created by luxiaoguo on 2018/6/5.
 */

public enum ScrollLauncherTag {
    HAS_FIRST_LAUNCHER_APP
}
