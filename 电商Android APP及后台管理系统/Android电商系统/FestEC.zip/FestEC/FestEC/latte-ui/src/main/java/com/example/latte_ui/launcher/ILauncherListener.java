package com.example.latte_ui.launcher;

/**
 * Created by luxiaoguo on 2018/6/6.
 */

public interface ILauncherListener {

    void onLauncherFinish(OnLauncherFinisTag tag);
}
