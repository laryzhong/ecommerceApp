package com.example.latte_ui.launcher;

/**
 * Created by luxiaoguo on 2018/6/6.
 */

public enum OnLauncherFinisTag {
    SIGNED,
    NOT_SIGNED
}
