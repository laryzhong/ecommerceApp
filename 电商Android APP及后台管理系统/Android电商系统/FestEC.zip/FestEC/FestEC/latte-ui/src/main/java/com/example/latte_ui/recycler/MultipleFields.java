package com.example.latte_ui.recycler;

/**
 * Created by luxiaoguo on 2018/6/11.
 */

public enum MultipleFields {
    ITEM_TYPE,
    TITLE,
    TEXT,
    IMAGE_URL,
    BANNERS,
    SPAN_SIZE,
    ID,
    NAME,
    TAG
}
